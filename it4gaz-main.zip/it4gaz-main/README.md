# it4gaz
## установка
установить пароль и логин для postgres в `example-docker-compose.yml`
и переименовать в `docker-compose.yml`
